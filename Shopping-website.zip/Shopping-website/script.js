// Initialize Swiper for the slider
document.addEventListener("DOMContentLoaded", function () {
    if (typeof Swiper !== 'undefined') { 
        const swiper = new Swiper('.home-slider', {
            loop: true,
            autoplay: {
                delay: 1500,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    } else {
        console.error("Swiper is not loaded!");
    }
});

// Cart functionality
function addToCart(productName, price, image) {
    // Retrieve existing cart from localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Check if the item already exists in the cart
    const existingItemIndex = cart.findIndex(item => item.name === productName);
    
    if (existingItemIndex > -1) {
        // If it exists, increase the quantity
        cart[existingItemIndex].quantity += 1;
    } else {
        // If it doesn't exist, add a new item
        cart.push({ name: productName, price: price, quantity: 1, image: image });
    }
    
    // Save the updated cart back to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount();

    // Show toast notification
    showToast(`${productName} has been added to your cart!`);
}

function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = message;
    document.body.appendChild(toast);

    // Remove the toast after a few seconds
    setTimeout(() => {
        toast.remove();
    }, 3000); // Adjust the duration as needed
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cart-count-icon').textContent = totalCount; // Ensure this ID exists in your HTML
}

// Category filtering
function showAll() {
    document.querySelectorAll('.category').forEach(category => {
        category.style.display = 'block';
    });
}

function showCategory(categoryName) {
    document.querySelectorAll('.category').forEach(category => {
        if (category.classList.contains(categoryName)) {
            category.style.opacity = "0";  
            setTimeout(() => {
                category.style.display = "block";
                category.style.opacity = "1";
            }, 300);
        } else {
            category.style.opacity = "0";  
            setTimeout(() => {
                category.style.display = "none";
            }, 300);
        }
    });
}

// Call this function on page load to set the initial count and show all categories
window.onload = function () {
    showAll(); // Show categories
    updateCartCount(); // Update cart count on page load
};